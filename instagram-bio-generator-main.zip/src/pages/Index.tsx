
import React from 'react';
import { IndexPage } from '@/components/index/IndexPage';

const Index = () => {
  return <IndexPage />;
};

export default Index;
